import java.util.*;
public class Lab1c {
Scanner sc=new Scanner(System.in);
boolean checkNumber(int number)
{
	boolean f=true;
	int c1,c2;
	int pn=number;
	while(pn!=0)
	{
		c1=pn%10;
		pn=pn/10;
		c2=pn%10;
		if(c1>=c2)
		{
			continue;
		}
		else
		{
			f=false;
			break;
		}
	}
	return f;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab1c obj=new Lab1c();
		System.out.println("Enter a number");
		int n=obj.sc.nextInt();
		if(obj.checkNumber(n))
		{
		System.out.println(n+" is an increasing Number");
		}
		else
		{
			System.out.println(n+" is not an increasing Number");
		}
		
	}

}
