import java.util.Arrays;
import java.util.Scanner;
public class Lab3a {
	Scanner sc=new Scanner(System.in);
	int getSecondSmallest(int[] a) {
		

		int min1=Integer.MAX_VALUE;
		int min2=Integer.MAX_VALUE;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<min1)
			{
				min2=min1;
				min1=a[i];
				
			}
			if(a[i]<min2&&a[i]>min1)
			{
				min2=a[i];
			}
		}
		return min2;
		
	}
 public static void main(String[] args)
 {
	 Lab3a obj=new Lab3a();
		int n=obj.sc.nextInt();
		int[] a=new int[n];
		System.out.println(" ");
	 for(int i=0;i<n;i++)
		{
			a[i]=obj.sc.nextInt();
		}
	
	int sm= obj.getSecondSmallest(a);
	System.out.println("second distinct smallest number is"+sm);

 }
}
