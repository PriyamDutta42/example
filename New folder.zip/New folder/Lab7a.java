import java.util.*;
public class Lab7a {
	List<String> getValues(HashMap<Integer,String> hm)
	{
		List<String> l=new ArrayList<String>();
		l.addAll(hm.values());
		Collections.sort(l);
		return l;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		int id;
		String name;
		int num; 
		System.out.println("Enter number of Elements");
		num=sc.nextInt();
		for(int i=0;i<num;i++)
		{
			id=sc.nextInt();
			name=sc.next();
			hm.put(id, name);
		}
		Lab7a obj=new Lab7a();
		System.out.println(obj.getValues(hm));
	}

}
