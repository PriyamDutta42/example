import java.util.*;
public class Lab4a {
int sumOfCube(int n)
{
	int sum=0;
	int c;
	while(n!=0)
	{
		c=n%10;
		sum+=(int)Math.pow(c, 3);
		n=n/10;
	}
	return sum;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab4a obj=new Lab4a();
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter a number");
		n=sc.nextInt();
		System.out.println("The sum of cubes of number is "+obj.sumOfCube(n));
	}

}
