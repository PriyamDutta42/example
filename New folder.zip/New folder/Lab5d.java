import java.util.*;
class MyException extends Exception
{
	MyException(String s)
	{
		super(s+" can't be empty");
	}
}
public class Lab5d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String f;
		String l;
		System.out.println("Enter First Name");
		
		try {
		f=sc.nextLine();
		if(f.isEmpty())
		{
			throw new MyException("First Name");
		}
		System.out.println("Enter Last Name");
		l=sc.nextLine();
	
		if(l.isEmpty())
		{
			throw new MyException("Last Name");
		}
		
		System.out.println("Entered Name is :"+f+l);
		}
		catch(MyException n)
		{
			System.out.println(n);
		}
		
			
		

	}

}
