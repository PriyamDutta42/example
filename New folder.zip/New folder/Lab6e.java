import java.util.Scanner;
public class Lab6e {
	boolean checkPositive(String s)
	{
		boolean f=true;
		s=s.toLowerCase();
		for(int i=0;i<s.length()-1;i++)
		{
			if((int)s.charAt(i)>=(int)s.charAt(i+1))
			{
				f=false;
				break;
			}
		}
		return f;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab6e obj=new Lab6e();
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		s=sc.next();
		if(obj.checkPositive(s))
		{
			System.out.println("Entered String is Positive");
		}
		else
		{
			System.out.println("Entered String is Negative");
		}

	}

}
