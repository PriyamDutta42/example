import java.util.*;
public class Lab5b {
int recfib(int n)
{
	if(n==1||n==0)
	{
		return n;
	}
	else {
		return recfib(n-1)+recfib(n-2);
	}
}
int fib(int n)
{
	int c=0;
	int a=0;
	int b=1;
	if(n==1||n==0)
	{
		return n;
	}
	else
	{
		for(int i=1;i<n;i++)
		{
			c=a+b;
			
			a=b;
			b=c;
		}
		return c;
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab5b obj=new Lab5b();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter nth number");
		int n=sc.nextInt();
		System.out.print("fibonacci's nth number with recusrsion=");
		System.out.println(obj.recfib(n));
		System.out.print("fibonacci's nth number without recusrsion=");
		System.out.print(obj.fib(n));
		
	}

}
