
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.*;
public class Lab5a {
JFrame f;
Lab5a()
{
	f=new JFrame();
	JRadioButton a1=new JRadioButton("Red");
	JRadioButton a2=new JRadioButton("Yellow");
	JRadioButton a3=new JRadioButton("Green");
	a1.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(ItemEvent e)
		{
			if(a1.isSelected())
			{
				System.out.println("Stop");
			}
		}
	});
	a2.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(ItemEvent e)
		{
			if(a2.isSelected())
			{
				System.out.println("Ready");
			}
		}
	});
	a3.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(ItemEvent e)
		{
			if(a3.isSelected())
			{
				System.out.println("Go");
			}
		}
	});
	a1.setBounds(80,60,100,40);
	a2.setBounds(80,120,100,40);
	a3.setBounds(80,180,100,40);
	ButtonGroup b=new ButtonGroup();
	b.add(a1);
	b.add(a2);
	b.add(a3);
	f.add(a1);
	f.add(a2);
	f.add(a3);
	f.setSize(500,500);
	f.setLayout(null);
	f.setVisible(true);
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Lab5a();
	}

}
