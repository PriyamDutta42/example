import java.util.*;
import java.util.regex.Pattern;
public class Lab6g {
boolean Validation(String s)
{
	boolean f=Pattern.matches("[a-zA-Z]{8,}_job", s);
	return f;
}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
//	String s=sc.next();
	System.out.println("Enter Username");
	String s=sc.next();
	Lab6g obj=new Lab6g();
	if(obj.Validation(s))
	{
		System.out.println("Correct Format");
	}
	else
	{
		System.out.println("Format Wrong");
		System.out.println("Format is minimum 8 characters to the left of _job");
	}
}

}
