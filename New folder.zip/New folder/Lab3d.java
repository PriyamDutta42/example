import java.util.*;
public class Lab3d {
void count(char a[])
{
	int[] count=new int[a.length];
	for(int  i=0;i<a.length;i++)
	{
		count[i]=-1;
	}
	
	int counting=1;
	for(int i=0;i<a.length;i++)
	{
		
		for(int j=i+1;j<a.length;j++)
		{
			if(a[i]==a[j]&&count[j]==-1)
			{
				counting++;
				count[j]++;
			}
			
		}
		if(count[i]==-1)
		{
		System.out.println("Count of "+a[i]+"="+counting);
		}
		counting=1;
		}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab3d obj=new Lab3d();
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter number");
		n=sc.nextInt();
		System.out.println("Enter array");
		char[] a=new char[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.next().charAt(0);
		}
		obj.count(a);
	}

}
