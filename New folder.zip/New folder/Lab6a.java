import java.util.*;
public class Lab6a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int sum=0;
		System.out.println("Enter a String");
		String s=sc.nextLine();
		String str;
		StringTokenizer st1=new StringTokenizer(s," ");
		while(st1.hasMoreTokens())
		{
			str=st1.nextToken();
			System.out.print(str+" ");
			sum+=Integer.parseInt(str);
		}
		System.out.println("\nThe sum is "+sum);
		

	}

}
