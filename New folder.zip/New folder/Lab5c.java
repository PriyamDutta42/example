import java.util.Scanner;

public class Lab5c {
boolean checkPrime(int n)
{
	boolean f=true;
	for(int i=2;i<=n/2;i++)
	{
		if(n%i==0)
		{
			f=false;
			break;
		}
	}
	return f;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab5c obj=new Lab5c();
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("Enter a number");
		n=sc.nextInt();
		System.out.println("All Prime numbers");
		for(int i=2;i<=n;i++)
		{
			if(obj.checkPrime(i))
			{
				System.out.print(i+" ");
			}
			else {
				continue;
			}
		}
	}

}
