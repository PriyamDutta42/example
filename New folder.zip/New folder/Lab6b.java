import java.io.*;
public class Lab6b {
void Linenumber() {
	BufferedReader fin=null;
	try {
		fin=new BufferedReader(new FileReader("Fileread.txt"));
		int i;
		String str;
		int count=0;
		while((str=fin.readLine())!=null)
		{
		 count++;
		 System.out.println(count+" "+str);
		}
	}
	catch(IOException e)
	{
		
	}

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab6b obj=new Lab6b();
		obj.Linenumber();
	}

}
