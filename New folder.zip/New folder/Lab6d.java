import java.io.File;
import java.util.*;
public class Lab6d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter File Name");
		String s=sc.next();
		File f=new File(s);
		String l = "";
		StringTokenizer d=new StringTokenizer(s,".");
		System.out.println("File Exists: "+f.exists());
		System.out.println("File is Readable: "+f.canRead());
		System.out.println("File is Writable: "+f.canWrite());
		if(f.exists())
		{
			while(d.hasMoreTokens()) {
				l=d.nextToken().toString();
			}
			System.out.println("File Type: "+l);
		}
		else
		{
			System.out.println("File Type: "+l);
		}
		
		System.out.println("File Length: "+f.length());
		sc.close();
		

	}

}
