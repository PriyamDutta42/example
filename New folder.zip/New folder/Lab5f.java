import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Lab5f {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int salary;
		System.out.println("Enter salary");
		try {
		salary=sc.nextInt();
		if(salary<3000)
		{
			throw new EmployeeException();
		}
		System.out.println("Your salary is :"+salary);
		}
		catch(EmployeeException e)
	{  
			System.out.println(e);
	
		}
	}

}
