import java.io.*;

public class Lab6c {
void ReadFile()
{
	FileInputStream fin=null;
	try {
		fin=new FileInputStream("Fileread.txt");
		int countWords=0,countChar=0,countLine=0,i;
		int countVar = 0 ;
		while((i=fin.read())!=-1)
		{
			if((char)i=='\n')
			{
				countLine++;
				countWords++;
				countVar = 0;		
			}
			if(i>13)
			{
				countChar++;
				countVar++;
			}
			if((char)i==' ')
			{
				countWords++;
				countChar--;
			}
		}
		if(countVar > 0)
			countLine++;

		
		System.out.println("The number of characters are ="+countChar+"\nThe number of Words are ="+countWords+"\nThe number of Lines are ="+countLine);
		fin.close();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab6c obj=new Lab6c();
		obj.ReadFile();
	}

}
