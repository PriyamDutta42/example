import java.util.*;
public class Lab1d {
Scanner sc=new Scanner(System.in);
boolean checkNumber(int n)
{
	boolean f=false;
	int i=1;
	int c=1;
	while(n>=c)
	{
		c=(int)Math.pow(2,i);
		if(n==c)
		{
			f=true;
			break;
		}
		else
		{
			i++;
		}
	}
	return f;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab1d obj=new Lab1d();
		System.out.println("Enter a number");
		int n=obj.sc.nextInt();
		if(obj.checkNumber(n))
		{
		System.out.println(n+" is a power of two");
		}
		else
		{
		System.out.println(n+" is not a power of two");
		}

	}

}
