import java.util.*;
public class Lab3b {
	
	String[] sorting(String s[])
	{
		int n;
		
		for(int i=0;i<s.length;i++)
		{
			s[i]=s[i].toLowerCase();
		}
		Arrays.sort(s);
		n=s.length/2+1;
		if((s.length)%2==0)
		{
			n=s.length/2;
		}
	
		for(int i=0;i<n;i++)
		{
			s[i]=s[i].toUpperCase();
		}
			
		return s;
	}
 public static void main(String[] args)
 {
	 Lab3b obj=new Lab3b();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number of elements");
	int n=sc.nextInt();
	String[] s=new String[n]; 
	System.out.println("enter array");
	for(int i=0;i<n;i++)
	{
		s[i]=sc.next();
	}
	s=obj.sorting(s);
	for(int i=0;i<n;i++)
	{
		System.out.print(s[i]+" ");
	}
	
 }
}
