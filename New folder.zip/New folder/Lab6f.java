import java.time.LocalDate;
import java.time.Period;
import java.util.*;
public class Lab6f {
void datediff(String str)
{
	String[] temp=new String[3];
	temp=str.split("/");
	int m;int y; int d;
	d=Integer.parseInt(temp[0]);
	m=Integer.parseInt(temp[1]);
	y=Integer.parseInt(temp[2]);
	LocalDate obj=LocalDate.of(y,m,d);
	LocalDate obj1=LocalDate.now();
	Period ob= Period.between(obj1,obj);
	System.out.println("Days="+ob.getDays()+"Months="+ob.getMonths()+"Years"+ob.getYears());
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab6f obj=new Lab6f();
		System.out.println("Enter Date in dd/mm/yyyy");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		obj.datediff(str);
	}

}
