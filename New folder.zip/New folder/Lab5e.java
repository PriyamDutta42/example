import java.util.*;
class Exception1 extends Exception
{
	Exception1()
	{
		super("Age of a person should be above 15");
	}
}
public class Lab5e {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int age;
		System.out.println("Enter Age");
		try {
		age=sc.nextInt();
		if(age<=15)
		{
			throw new Exception1();
		}
		System.out.println("Your age is :"+age);
		}
		catch(Exception1 e)
	{  
			System.out.println(e);
	
		}
				
	}

}
