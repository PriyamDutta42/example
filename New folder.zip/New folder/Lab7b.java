import java.util.*;

public class Lab7b {
LinkedHashMap<Character,Integer> countCharacter(char[] c)
{
	LinkedHashMap<Character,Integer> hm=new LinkedHashMap<Character,Integer>();
	for(int i=0;i<c.length;i++)
	{
		if(!hm.containsKey(c[i]))
		{
			hm.put(c[i], 1);
		}
		else
		{
			hm.put(c[i], hm.get(c[i])+1);
		}
	}
	return hm;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		
		
		System.out.println("Enter String");
		String s=sc.next();
		char[] c=s.toCharArray();
		
		Lab7b obj=new Lab7b();
		
		System.out.println(obj.countCharacter(c));
		sc.close();
}
}
