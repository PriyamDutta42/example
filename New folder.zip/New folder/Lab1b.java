import java.util.*;
public class Lab1b {
	Scanner sc=new Scanner(System.in);
int calculateDifference(int n)
{
	int sum=0;
	int sqsum=0;
	for(int i=1;i<=n;i++)
	{
		sqsum+=Math.pow(i,2);
		sum+=i;
		
	}

	sum=(int)Math.pow(sum,2);
	return (sqsum-sum);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Lab1b obj=new Lab1b();
		
		System.out.println("Enter a number");
		int n=obj.sc.nextInt();
		System.out.println("Difference is "+obj.calculateDifference(n));

	}

}
