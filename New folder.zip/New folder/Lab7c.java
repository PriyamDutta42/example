import java.util.*;
public class Lab7c {
LinkedHashMap<Integer,Integer> getSquares(int n[])
{
	LinkedHashMap<Integer,Integer> hm=new LinkedHashMap<Integer,Integer>();
	for(int i=0;i<n.length;i++)
	{
		hm.put(n[i], (int)Math.pow(n[i],2));
	}
	return hm;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		int num;
		ArrayList<Integer> al=new ArrayList<Integer>();
		System.out.println("Enter number of elements");
		num=sc.nextInt();
		int[] a=new int[num];
		for(int i=0;i<num;i++)
		{
			a[i]=sc.nextInt();
			
		}
		
		Lab7c obj=new Lab7c();
		
		System.out.println(obj.getSquares(a));
	}

}
